#ifndef JOUEUR_H
#define JOUEUR_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>


typedef struct
{

SDL_Texture *normal;
SDL_Texture *hover;

SDL_Rect pos;

int hoverState;

}Button;



typedef struct
{

SDL_Texture *background;


/* audio */

Mix_Music *music;
Mix_Chunk *click;


/* boutons */

Button mono;
Button multi;

Button avatar1;
Button avatar2;

Button input1;
Button input2;

Button valider;
Button retour;


int etat;

}MenuJoueur;



void initMenu(MenuJoueur *m,SDL_Renderer *renderer);

void afficherMenu(MenuJoueur m,SDL_Renderer *renderer);

int eventMenu(MenuJoueur *m,SDL_Event event);

void freeMenu(MenuJoueur *m);

#endif
