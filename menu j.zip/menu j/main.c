#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>   // ⭐ AJOUT

#include "joueur.h"



int main()
{


/* initialisation SDL */

SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);


/* initialisation image */

IMG_Init(IMG_INIT_PNG | IMG_INIT_JPG);


/* initialisation audio */

Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,2,2048);




/* creation fenetre */

SDL_Window *window;

SDL_Renderer *renderer;



window =
SDL_CreateWindow("Sous Menu Joueur",

SDL_WINDOWPOS_CENTERED,
SDL_WINDOWPOS_CENTERED,

900,500,

0);




renderer =
SDL_CreateRenderer(window,-1,

SDL_RENDERER_ACCELERATED);




/* creation menu */

MenuJoueur menu;

initMenu(&menu,renderer);




SDL_Event event;

int quit=0;

int retour;



/* boucle principale */

while(!quit)
{


while(SDL_PollEvent(&event))
{


if(event.type==SDL_QUIT)

quit=1;



/* gestion menu */

retour = eventMenu(&menu,event);



if(retour==2)
{

printf("Retour menu principal\n");

}


if(retour==1)
{

printf("Aller menu score\n");

}


}




SDL_RenderClear(renderer);


afficherMenu(menu,renderer);


SDL_RenderPresent(renderer);



}



/* liberation */

freeMenu(&menu);



Mix_CloseAudio();



SDL_DestroyRenderer(renderer);

SDL_DestroyWindow(window);



IMG_Quit();

SDL_Quit();



return 0;

}
