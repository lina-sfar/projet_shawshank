#include "joueur.h"



void initButton(Button *b,SDL_Renderer *renderer,char normal[],char hover[],int x,int y)
{

b->normal = IMG_LoadTexture(renderer,normal);
b->hover = IMG_LoadTexture(renderer,hover);

b->pos.x=x;
b->pos.y=y;
b->pos.w=200;
b->pos.h=60;

b->hoverState=0;

}



int mouseOver(Button b,int x,int y)
{

return x>b.pos.x &&
       x<b.pos.x+b.pos.w &&
       y>b.pos.y &&
       y<b.pos.y+b.pos.h;

}




void initMenu(MenuJoueur *m,SDL_Renderer *renderer)
{


m->background = IMG_LoadTexture(renderer,"image.jpg");


/* music */

m->music = Mix_LoadMUS("sound2.mp3");

Mix_PlayMusic(m->music,-1);



/* click */

m->click = Mix_LoadWAV("sound1.mp3");



/* interface 1 */

initButton(&m->mono,renderer,"mono2.png","mono.png",200,200);

initButton(&m->multi,renderer,"multi.png","multi2.png",500,200);



/* interface 2 */

initButton(&m->avatar1,renderer,"avat1.png","avat12.png",200,150);

initButton(&m->avatar2,renderer,"avat2.png","avat22.png",500,150);

initButton(&m->input1,renderer,"inp1.png","inp12.png",200,250);

initButton(&m->input2,renderer,"inp2.png","inp22.png",500,250);

initButton(&m->valider,renderer,"valid.png","valid2.png",350,350);



/* retour */

initButton(&m->retour,renderer,"ret.png","ret2.png",650,420);


m->etat=0;

}




void afficherButton(Button b,SDL_Renderer *renderer)
{

if(b.hoverState)
SDL_RenderCopy(renderer,b.hover,NULL,&b.pos);

else
SDL_RenderCopy(renderer,b.normal,NULL,&b.pos);

}




void afficherMenu(MenuJoueur m,SDL_Renderer *renderer)
{

SDL_RenderCopy(renderer,m.background,NULL,NULL);


if(m.etat==0)
{

afficherButton(m.mono,renderer);
afficherButton(m.multi,renderer);

}

else
{

afficherButton(m.avatar1,renderer);
afficherButton(m.avatar2,renderer);
afficherButton(m.input1,renderer);
afficherButton(m.input2,renderer);
afficherButton(m.valider,renderer);

}


afficherButton(m.retour,renderer);

}




int eventMenu(MenuJoueur *m,SDL_Event event)
{

int x,y;

SDL_GetMouseState(&x,&y);


/* sauvegarde ancien hover */

int oldMono=m->mono.hoverState;
int oldMulti=m->multi.hoverState;
int oldAvatar1=m->avatar1.hoverState;
int oldAvatar2=m->avatar2.hoverState;
int oldInput1=m->input1.hoverState;
int oldInput2=m->input2.hoverState;
int oldValider=m->valider.hoverState;
int oldRetour=m->retour.hoverState;



/* update hover */

m->mono.hoverState=mouseOver(m->mono,x,y);
m->multi.hoverState=mouseOver(m->multi,x,y);

m->avatar1.hoverState=mouseOver(m->avatar1,x,y);
m->avatar2.hoverState=mouseOver(m->avatar2,x,y);

m->input1.hoverState=mouseOver(m->input1,x,y);
m->input2.hoverState=mouseOver(m->input2,x,y);

m->valider.hoverState=mouseOver(m->valider,x,y);

m->retour.hoverState=mouseOver(m->retour,x,y);



/* sound hover */

if(m->mono.hoverState && !oldMono) Mix_PlayChannel(-1,m->click,0);
if(m->multi.hoverState && !oldMulti) Mix_PlayChannel(-1,m->click,0);
if(m->avatar1.hoverState && !oldAvatar1) Mix_PlayChannel(-1,m->click,0);
if(m->avatar2.hoverState && !oldAvatar2) Mix_PlayChannel(-1,m->click,0);
if(m->input1.hoverState && !oldInput1) Mix_PlayChannel(-1,m->click,0);
if(m->input2.hoverState && !oldInput2) Mix_PlayChannel(-1,m->click,0);
if(m->valider.hoverState && !oldValider) Mix_PlayChannel(-1,m->click,0);
if(m->retour.hoverState && !oldRetour) Mix_PlayChannel(-1,m->click,0);



/* click */

if(event.type==SDL_MOUSEBUTTONDOWN)
{

if(m->mono.hoverState || m->multi.hoverState)
m->etat=1;


if(m->valider.hoverState)
return 1;



if(m->retour.hoverState)
{

if(m->etat==1)

m->etat=0;

else

return 2;

}

}


return 0;

}




void freeMenu(MenuJoueur *m)
{

SDL_DestroyTexture(m->background);

Mix_FreeMusic(m->music);
Mix_FreeChunk(m->click);

}
